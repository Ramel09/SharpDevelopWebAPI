﻿using System;

namespace SharpDevelopWebApi.Models
{
	public class Faculty: Person
	{
		public string SSSNumber { get; set; }
		public string SuperVisor { get; set;}
	}
}
