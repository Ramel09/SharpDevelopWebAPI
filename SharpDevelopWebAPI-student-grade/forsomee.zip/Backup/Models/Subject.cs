﻿
using System;

namespace SharpDevelopWebApi.Models
{

	public class Subject
	{
		public int Id { get; set; }
		public string Code { get; set; } //ITE-009, ENG-101
		public string DescriptiveTitle { get; set; }
	}
}
